package com.interview.peoplemanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PeopleManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(PeopleManagerApplication.class, args);
	}

}
