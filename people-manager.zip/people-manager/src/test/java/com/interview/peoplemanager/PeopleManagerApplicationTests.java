package com.interview.peoplemanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeopleManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
